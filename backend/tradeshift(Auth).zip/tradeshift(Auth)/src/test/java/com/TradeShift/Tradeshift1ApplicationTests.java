package com.TradeShift;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tradeshift1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
