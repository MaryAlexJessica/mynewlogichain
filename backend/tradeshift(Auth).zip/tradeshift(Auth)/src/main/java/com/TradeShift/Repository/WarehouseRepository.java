package com.TradeShift.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.TradeShift.Entity.Warehouse;

public interface WarehouseRepository extends JpaRepository<Warehouse, Long> {

}
