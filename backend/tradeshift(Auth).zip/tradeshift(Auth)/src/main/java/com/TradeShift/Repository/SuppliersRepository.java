package com.TradeShift.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.TradeShift.Entity.Suppliers;

public interface SuppliersRepository extends JpaRepository<Suppliers, Long> {

}
